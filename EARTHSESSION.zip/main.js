
      $(function(){
           $(window).scroll(function(){
         if($(window).scrollTop() > 0){
               $("#top").css({"display":"block"});
            }else{
               $("#top").css({"display":"none"});
             }
  			});
         });


      $(function(){
         $("#slide_nav").animate({"margin-left":"0px"}, 1000);
         $("#slide_button2").animate({"margin-left":"400px"}, 1000);
         setTimeout(function() {
              $("#slide_nav").animate({"margin-left":"-400px"});
            $("#slide_button2").animate({"margin-left":"0px"});
            }, 5000);

      });


   $(function(){
	   $("#CLS2").hover(
	  function() {
	    $(this).text("환경보호");
	    $(this).css({"line-height":"20px"});
	  }, function() {
	    $(this).text("Environment");

	  });
	    $("#CLS3").hover(
	  function() {
	    $(this).text("취약계층");
	    $(this).css({"line-height":"20px"});
	  }, function() {
	    $(this).text("Vulnerable");
	  });
	     $("#CLS4").hover(
	  function() {
	    $(this).text("동물보호");
	    $(this).css({"line-height":"20px"});
	  }, function() {
	    $(this).text("animal");
	  });
	      $("#CLS5").hover(
	  function() {
	    $(this).text("후원&캠페인");
	    $(this).css({"line-height":"20px"});
	  }, function() {
	    $(this).text("support");
	  });
});

		$(function(){
            $("#slide_button2").click(function(){
                $("#slide_nav").animate({"margin-left":"0"});
                $("#slide_button2").css({"display":"none"});
                $("#slide_button").delay(1000).css({"display":"block"});

            });
         });

		$(function(){
            $("#slide_button").click(function(){
               $("#slide_nav").animate({"margin-left":"-400px"});
                $("#slide_button2").css({"display":"block"});
                $("#slide_button").css({"display":"none"});
            });
         });

     var $paragraph = $("#t1")// 변수값다르게 지정ㅇ

    $(window).scroll(function(){
      $paragraph.each(function(){
        paragraphMiddle = $(this).offset().top + (0.01 *$(this).height());
        windowBottom = $(window).scrollTop() + $(window).height();//조건

        if(paragraphMiddle > windowBottom) {
          $(this).addClass("paraFadeIn");//클래스 이름 다르게 지정

        }
        else {
          $(this).removeClass("paraFadeIn");
        }
      });
    });

  	$(function(){
  		$("top_up").click(function(){
  			var section = $("#section0");
  			var sectionDistance = section.offset().top;
  			$("html").stop().animate({scrollTop:sectionDistance});
  		});
  	});


	<!--[if IE]>
		<script type="text/javascript">
			 var console = { log: function() {} };

	<![endif]-->